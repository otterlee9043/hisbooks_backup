from django.shortcuts import render
from django.db import connection
from .models import *
from django.core.files.storage import default_storage
from django.views.generic import TemplateView
import pandas as pd
from PIL import Image
import base64
from io import BytesIO

# Create your views here.
def index4(request):
    print("index4")
    
    return render(request, "index4.html")

def upload(request):
    print("Uploaded~")
    return render(request, "searchenter.html")

class PostUpload(TemplateView):
    template_name="searchenter.html"

    def get(self, request):
        print("get!")
        return render(request, 'index4.html', {"did_search": False})
    def post(self, request):
        print("post..")
        if request.method == 'POST':
            book_title = request.POST['bookTitle']
            price = request.POST['price']
            course = request.POST['course']
            quality = request.POST['quality']
            description = request.POST['description']
            # image = request.POST.get('frontImg', False)
            image = request.FILES['frontImg']
            buffer = BytesIO()
            im = Image.open(image)
            im.save(buffer, format='jpeg')
            img_str = base64.b64encode(buffer.getvalue())
            img_str = img_str.decode('UTF-8')
            # blob_value = open(image, 'rb').read()

            print(image)
        cursor = connection.cursor()
        # qry = "SELECT * FROM Classes WHERE course_id = '" + course_id + "' and section_id IN('" + section_id +"', '0" + section_id +"') ;"
        # cursor.execute(qry)
        
        print("Price is " + price)

        query = """
        INSERT INTO Used_Book_Info (user_id, description, ISBN, price, date, quality, image) 
        VALUES ('sua@handong.edu', '"""+ description + """', '9791156641131', """+ price + """, CURRENT_TIMESTAMP, """ + quality + """, '""" + img_str+"""');"""
        
        print(query)
        cursor.execute(query)
        # coursebook_info = cursor.fetchone()

        # print(course_info)
        # print(coursebook_info)

        return render(request, 'index4.html', {"did_search": True})




        
def do_usedbooksearch(request, book_title):
    print("Call!")
    if request.method == 'GET':
        book_title = request.GET['book_title']
        print("The book_title is "+book_title)

    cur = connection.cursor()
    # 책 제목 0, 가격 1, 상태 2, 사진 3, 내용 4, 말머리 5, 날짜 6
    query ="SELECT title, price, quality, image, description, is_sold, date FROM Book_Info JOIN Used_Book_Info ON Book_Info.ISBN = Used_Book_Info.ISBN AND Book_Info.title='"+ book_title+"';"

    # print(query)
    # cur.execute("SELECT * FROM Book_Info JOIN Used_Book_Info ON Book_Info.ISBN = Used_Book_Info.ISBN AND Book_Info.title='"+ book_title+"';")
    # book_list = cur.fetchall()

    #print(query)
    print("Book list")
    # book_list = UsedBookInfo.objects.raw(query)
    # print(book_list)
    cur.execute(query)
    book_list = cur.fetchall()

    # for entry in book_list:
    #     entry[3] = entry[3].encode("UTF-8")
    #     entry[3] = base64.b64decode(entry[3])
    
    print(book_list)

    return render(request, "index4.html", {"book_list" :book_list})
