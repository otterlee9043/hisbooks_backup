from django.urls import path
from .views import index4, do_usedbooksearch, upload, PostUpload
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', PostUpload.as_view(), name='index4'),
    path('<str:book_title>', do_usedbooksearch, name='index4'),
    path('upload/', upload, name='upload'),
    # path('submit_post/', PostUpload.as_view(), name='submit_post'),
]  